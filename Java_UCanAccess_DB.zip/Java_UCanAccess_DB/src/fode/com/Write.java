package fode.com;

public class Write {

	public Write() {
		// TODO Auto-generated constructor stub
	}

}
