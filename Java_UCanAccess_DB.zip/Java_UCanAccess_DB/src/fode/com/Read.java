package fode.com;

public class Read {

	public Read() {
		// TODO Auto-generated constructor stub
	}

}
